exports.handler = async function(event) {
    try {
        return {
                statusCode: 202,
                body: JSON.stringify({ message: 'App Working!'})
        }
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal Server Error ' + error })
        };
    }
};